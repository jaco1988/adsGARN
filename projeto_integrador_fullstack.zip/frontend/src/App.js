import Produto from './pages/Produto';
import Fornecedor from './pages/Fornecedor';
import Associacao from './pages/Associacao';
export default function App(){return (<><Produto/><Fornecedor/><Associacao/></>);}
